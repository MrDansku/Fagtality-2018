#pragma once

class CHud
{
public:
	MFUNC( FindElement( const char* name ), void*( __thiscall * )( void*, const char* ), offsets::find_element )( name )
};

extern CHud* g_pHud;